import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const EMOJI_CATEGORIES = {
  'Često korišteno': ['😊', '❤️', '😂', '👍', '🎉', '😍', '🔥', '✨', '💯', '🙌', '😘', '💕'],
  'Smajlići': ['😀', '😃', '😄', '😁', '😅', '😆', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🥸', '🤩', '🥳'],
  'Simboli': ['❤️', '💕', '💖', '💗', '💙', '💚', '💛', '🧡', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💞', '💓', '💗', '💖', '💘', '💝', '✨', '⭐', '🌟', '💫', '⚡', '🔥', '💥', '✅', '❌'],
  'Priroda': ['🌸', '🌺', '🌻', '🌷', '🌹', '🥀', '🌾', '🌿', '☘️', '🍀', '🍃', '🍂', '🍁', '🌍', '🌎', '🌏', '🌙', '⭐', '☀️', '⛅', '☁️', '🌧️', '⛈️', '🌈'],
};

export default function EmojiPicker({ isOpen, onClose, onEmojiSelect }) {
  const [activeCategory, setActiveCategory] = React.useState('Često korišteno');

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="absolute bottom-full left-0 right-0 bg-white rounded-t-3xl shadow-2xl"
          style={{ height: '60vh', marginBottom: '8px' }}
        >
          <div className="h-full flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-bold text-gray-900">Emojiji</h3>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Categories */}
            <div className="flex gap-2 px-4 py-3 border-b overflow-x-auto">
              {Object.keys(EMOJI_CATEGORIES).map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                    activeCategory === category
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Emoji Grid */}
            <div className="flex-1 overflow-y-auto p-4">
              <div className="grid grid-cols-8 gap-2">
                {EMOJI_CATEGORIES[activeCategory].map((emoji, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      onEmojiSelect(emoji);
                      onClose();
                    }}
                    className="aspect-square flex items-center justify-center text-3xl hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}