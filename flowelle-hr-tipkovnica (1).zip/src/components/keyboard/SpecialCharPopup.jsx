import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const SPECIAL_CHARS = [
  ['@', '#', '%', '&', '*', '÷', '='],
  ['(', ')', '[', ']', '{', '}', '/', '_'],
  ['"', "'", ':', ';', '...', '°', '€', '$', '£']
];

export default function SpecialCharPopup({ isOpen, onSelect }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          className="absolute bg-white rounded-2xl shadow-2xl p-3 z-50"
          style={{
            bottom: '110%',
            left: '50%',
            transform: 'translateX(-50%)',
            marginBottom: '10px'
          }}
        >
          <div className="flex flex-col gap-2">
            {SPECIAL_CHARS.map((row, rowIndex) => (
              <div key={rowIndex} className="flex gap-2">
                {row.map((char) => (
                  <button
                    key={char}
                    onClick={() => onSelect(char)}
                    className="w-10 h-10 flex items-center justify-center text-xl font-semibold
                      bg-gray-50 hover:bg-blue-100 rounded-lg transition-colors
                      border border-gray-200"
                  >
                    {char}
                  </button>
                ))}
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}