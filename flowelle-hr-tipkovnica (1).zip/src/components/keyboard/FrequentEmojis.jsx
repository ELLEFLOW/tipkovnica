import React from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const FREQUENT_EMOJIS = ['😊', '❤️', '😂', '👍', '🎉', '😍', '🔥'];

export default function FrequentEmojis({ onEmojiClick, isVisible, onToggle }) {
  return (
    <div className="relative">
      {/* Zavjesa preko emojija kada su zatvoreni - NE pokriva tipku */}
      <AnimatePresence>
        {!isVisible && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 rounded-2xl pointer-events-none"
            style={{ 
              zIndex: 5,
              right: 'calc(12.5% + 8px)', // Izuzima zadnju tipku
              background: 'linear-gradient(to bottom, rgb(209, 213, 219), rgb(156, 163, 175))',
              opacity: 0.5
            }}
          />
        )}
      </AnimatePresence>

      {/* Emoji redak */}
      <motion.div 
        animate={{ 
          opacity: isVisible ? 1 : 0.85,
          scale: isVisible ? 1 : 0.98
        }}
        transition={{ duration: 0.2 }}
        className="flex gap-2 px-2 py-1.5 bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl relative"
        style={{ zIndex: 1 }}
      >
        {FREQUENT_EMOJIS.map((emoji, index) => (
          <button
            key={index}
            onClick={() => onEmojiClick(emoji)}
            disabled={!isVisible}
            className="flex-1 aspect-square flex items-center justify-center text-2xl
              bg-white rounded-xl hover:bg-gray-100 transition-colors shadow-sm
              disabled:cursor-not-allowed"
          >
            {emoji}
          </button>
        ))}
        
        {/* Tipka za zatvaranje/otvaranje */}
        <button
          onClick={onToggle}
          className="flex-1 aspect-square flex items-center justify-center
            bg-gray-200 rounded-xl hover:bg-gray-300 transition-colors shadow-sm relative"
          style={{ zIndex: 10 }}
        >
          {isVisible ? (
            <ChevronDown className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronUp className="w-5 h-5 text-gray-600" />
          )}
        </button>
      </motion.div>
    </div>
  );
}