import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';

export default function KeyboardKey({ 
  char, 
  width = '9.5%', 
  onClick, 
  onLongPress,
  isSpecial = false,
  bgColor = 'bg-white',
  icon = null,
  fontSize = 'text-2xl'
}) {
  const [isPressed, setIsPressed] = useState(false);
  const longPressTimer = useRef(null);

  const handlePressStart = () => {
    setIsPressed(true);
    if (onLongPress) {
      longPressTimer.current = setTimeout(() => {
        onLongPress();
      }, 500);
    }
  };

  const handlePressEnd = () => {
    setIsPressed(false);
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const handleClick = () => {
    if (onClick && !longPressTimer.current) {
      onClick(char);
    }
  };

  return (
    <motion.button
      className={`${bgColor} rounded-xl shadow-md ${fontSize} font-semibold 
        flex items-center justify-center transition-all duration-150
        ${isPressed ? 'scale-95' : 'scale-100'}
        ${isSpecial ? 'text-gray-600' : 'text-gray-900'}`}
      style={{ 
        width: width,
        height: '100%',
        minHeight: '50px',
        border: '1px solid rgba(0,0,0,0.05)'
      }}
      onMouseDown={handlePressStart}
      onMouseUp={handlePressEnd}
      onMouseLeave={handlePressEnd}
      onTouchStart={handlePressStart}
      onTouchEnd={handlePressEnd}
      onClick={handleClick}
      whileTap={{ scale: 0.95 }}
    >
      {icon || char}
    </motion.button>
  );
}