
import React, { useState, useRef, useEffect } from 'react';
import { Delete, CornerDownLeft, Globe, ArrowLeft } from 'lucide-react';
import KeyboardKey from '../components/keyboard/KeyboardKey';
import EmojiPicker from '../components/keyboard/EmojiPicker';
import SpecialCharPopup from '../components/keyboard/SpecialCharPopup';
import FrequentEmojis from '../components/keyboard/FrequentEmojis';

const LAYOUTS = {
  hr: {
    lowercase: [
      ['x', 'e', 'r', 't', 'i', 'u', 'o', 'p', 'z', 'h'],
      ['š', 's', 'a', 'd', 'f', 'k', 'j', 'g', 'h', 'đ'],
      ['!', 'ABC', 'č', 'v', 'c', 'n', 'm', 'l', 'ć', 'ž', 'BACK']
    ],
    uppercase: [
      ['X', 'E', 'R', 'T', 'I', 'U', 'O', 'P', 'Z', 'H'],
      ['Š', 'S', 'A', 'D', 'F', 'K', 'J', 'G', 'H', 'Đ'],
      ['!', 'abc', 'Č', 'V', 'C', 'N', 'M', 'L', 'Ć', 'Ž', 'BACK']
    ],
    numbers: [
      ['7', '8', '9', '/'],
      ['4', '5', '6', '*'],
      ['1', '2', '3', '-'],
      ['0', '.', '.', '+'],
      ['DELETE', 'ABC', '=']
    ],
    symbols: [
      ['[', ']', '{', '}', '#', '%', '^', '*', '+', '='],
      ['_', '\\', '|', '~', '<', '>', '$', '£', '¥', '·'],
      ['123', '.', ',', '?', '!', "'", 'BACK']
    ]
  },
  en: {
    lowercase: [
      ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
      ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
      ['ABC', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'BACK']
    ],
    uppercase: [
      ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
      ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
      ['abc', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'BACK']
    ],
    numbers: [
      ['7', '8', '9', '/'],
      ['4', '5', '6', '*'],
      ['1', '2', '3', '-'],
      ['0', '.', '.', '+'],
      ['DELETE', 'ABC', '=']
    ],
    symbols: [
      ['[', ']', '{', '}', '#', '%', '^', '*', '+', '='],
      ['_', '\\', '|', '~', '<', '>', '€', '£', '¥', '·'],
      ['123', '.', ',', '?', '!', "'", 'BACK']
    ]
  }
};

export default function Tipkovnica() {
  const [text, setText] = useState('');
  const [language, setLanguage] = useState('hr');
  const [keyboardMode, setKeyboardMode] = useState('lowercase');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showSpecialChars, setShowSpecialChars] = useState(false);
  const [keyboardHeight, setKeyboardHeight] = useState('42vh');
  const [isLanguageChanging, setIsLanguageChanging] = useState(false);
  const [showFrequentEmojis, setShowFrequentEmojis] = useState(true);
  const textareaRef = useRef(null);

  useEffect(() => {
    const updateHeight = () => {
      const height = window.innerHeight * 0.42;
      setKeyboardHeight(`${height}px`);
    };
    updateHeight();
    window.addEventListener('resize', updateHeight);
    return () => window.removeEventListener('resize', updateHeight);
  }, []);

  const getCurrentLayout = () => {
    return LAYOUTS[language][keyboardMode];
  };

  const handleKeyPress = (key) => {
    if (key === 'BACK' || key === 'DELETE') {
      setText(text.slice(0, -1));
    } else if (key === 'ABC' || key === 'abc') {
      setKeyboardMode(keyboardMode === 'lowercase' ? 'uppercase' : 'lowercase');
    } else if (key === '123') {
      setKeyboardMode('numbers');
    } else if (key === '#+=') {
      setKeyboardMode('symbols');
    } else if (key === 'SPACE') {
      setText(text + ' ');
    } else if (key === 'ENTER') {
      setText(text + '\n');
    } else {
      setText(text + key);
      if (keyboardMode === 'uppercase') {
        setKeyboardMode('lowercase');
      }
    }
  };

  const handleLongPress = () => {
    setShowSpecialChars(true);
  };

  const handleSpecialCharSelect = (char) => {
    setText(text + char);
    setShowSpecialChars(false);
  };

  const handleEmojiSelect = (emoji) => {
    setText(text + emoji);
  };

  const toggleLanguage = () => {
    setIsLanguageChanging(true);
    setTimeout(() => {
      setLanguage(language === 'hr' ? 'en' : 'hr');
      setKeyboardMode('lowercase');
      setTimeout(() => setIsLanguageChanging(false), 300);
    }, 150);
  };

  const layout = getCurrentLayout();
  const isNumberLayout = keyboardMode === 'numbers';

  return (
    <div className="w-full h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex flex-col overflow-hidden">
      <div className="p-4 bg-white shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900">Hrvatska Tipkovnica</h1>
        <p className="text-sm text-gray-600">
          Jezik: <span className="font-semibold text-blue-600">{language === 'hr' ? 'Hrvatski 🇭🇷' : 'English 🇬🇧'}</span>
        </p>
      </div>

      <div className="flex-1 p-4 overflow-hidden">
        <div className="bg-white rounded-xl shadow-lg p-4 h-full">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full h-full text-xl resize-none focus:outline-none text-gray-900 font-sans"
            placeholder="Počnite pisati..."
          />
        </div>
      </div>

      <div 
        className="relative bg-gradient-to-b from-gray-100 to-gray-200 border-t-2 border-gray-300 flex-shrink-0"
        style={{ height: keyboardHeight }}
      >
        <EmojiPicker
          isOpen={showEmojiPicker}
          onClose={() => setShowEmojiPicker(false)}
          onEmojiSelect={handleEmojiSelect}
        />

        <SpecialCharPopup
          isOpen={showSpecialChars}
          onSelect={handleSpecialCharSelect}
        />

        <div className="h-full flex flex-col p-2 pt-1 pb-8 md:pb-2">
          {!isNumberLayout && (
            <div className="relative">
              <FrequentEmojis 
                onEmojiClick={handleEmojiSelect} 
                isVisible={showFrequentEmojis}
                onToggle={() => setShowFrequentEmojis(!showFrequentEmojis)}
              />
            </div>
          )}

          <div className={`flex-1 flex flex-col gap-2 ${!isNumberLayout ? 'mt-1' : 'mt-3'}`}>
            {isNumberLayout ? (
              <>
                {/* Number Layout - 4 rows of numbers */}
                {layout.slice(0, 4).map((row, rowIndex) => (
                  <div key={rowIndex} className="flex gap-2 justify-center" style={{ height: '18%' }}>
                    {row.map((key, index) => (
                      <KeyboardKey
                        key={index}
                        char={key}
                        onClick={handleKeyPress}
                        width="22%"
                      />
                    ))}
                  </div>
                ))}

                {/* Bottom row with special buttons */}
                <div className="flex gap-2 justify-center" style={{ height: '18%' }}>
                  <button
                    onClick={() => handleKeyPress('DELETE')}
                    className="bg-gray-300 rounded-xl shadow-md flex items-center justify-center
                      hover:bg-gray-400 active:scale-95 transition-all duration-150"
                    style={{ width: '22%' }}
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>

                  <button
                    onClick={() => setKeyboardMode('lowercase')}
                    className="bg-gray-300 rounded-xl shadow-md flex items-center justify-center
                      hover:bg-gray-400 active:scale-95 transition-all duration-150 text-base font-semibold"
                    style={{ width: '22%' }}
                  >
                    ABC
                  </button>

                  <KeyboardKey
                    char="="
                    onClick={handleKeyPress}
                    width="22%"
                  />
                </div>
              </>
            ) : (
              <>
                {/* Regular keyboard layout */}
                <div className="flex gap-1.5" style={{ height: '22%' }}>
                  {layout[0].map((key, index) => (
                    <KeyboardKey
                      key={index}
                      char={key}
                      onClick={handleKeyPress}
                      width={`${100 / layout[0].length - 0.5}%`}
                    />
                  ))}
                </div>

                <div className="flex gap-1.5 px-4" style={{ height: '22%' }}>
                  {layout[1].map((key, index) => (
                    <KeyboardKey
                      key={index}
                      char={key}
                      onClick={handleKeyPress}
                      width={`${100 / layout[1].length - 0.5}%`}
                    />
                  ))}
                </div>

                <div className="flex gap-1.5" style={{ height: '22%' }}>
                  {layout[2].map((key, index) => {
                    if (key === 'BACK') {
                      return (
                        <KeyboardKey
                          key={index}
                          char={key}
                          onClick={handleKeyPress}
                          width="11%"
                          bgColor="bg-gray-300"
                          icon={<Delete className="w-5 h-5" />}
                        />
                      );
                    }
                    if (key === '!' && language === 'hr' && (keyboardMode === 'lowercase' || keyboardMode === 'uppercase')) {
                      return (
                        <KeyboardKey
                          key={index}
                          char={key}
                          onClick={handleKeyPress}
                          onLongPress={handleLongPress}
                          width="8%"
                        />
                      );
                    }
                    if (key === 'ABC' || key === 'abc' || key === '123' || key === '#+=') {
                      return (
                        <KeyboardKey
                          key={index}
                          char={key}
                          onClick={handleKeyPress}
                          width="11%"
                          bgColor="bg-gray-300"
                          fontSize="text-base"
                        />
                      );
                    }
                    return (
                      <KeyboardKey
                        key={index}
                        char={key}
                        onClick={handleKeyPress}
                        width={`${100 / layout[2].length - 1}%`}
                      />
                    );
                  })}
                </div>

                <div className="flex gap-1.5" style={{ height: '22%' }}>
                  <KeyboardKey
                    char={(keyboardMode === 'lowercase' || keyboardMode === 'uppercase') ? '123' : 'ABC'}
                    onClick={() => setKeyboardMode((keyboardMode === 'lowercase' || keyboardMode === 'uppercase') ? 'numbers' : 'lowercase')}
                    width="14%"
                    bgColor="bg-gray-300"
                    fontSize="text-base"
                  />

                  <div className="relative" style={{ width: '8%' }}>
                    <KeyboardKey
                      char=","
                      onClick={handleKeyPress}
                      onLongPress={handleLongPress}
                      width="100%"
                    />
                    <div className="absolute top-1 left-1/2 -translate-x-1/2 text-xs text-gray-400 pointer-events-none font-semibold">
                      #
                    </div>
                  </div>

                  <button
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="bg-yellow-400 rounded-xl shadow-md flex items-center justify-center
                      hover:bg-yellow-500 active:scale-95 transition-all duration-150"
                    style={{ width: '9%' }}
                  >
                    <span className="text-xl">😊</span>
                  </button>

                  <KeyboardKey
                    char="?"
                    onClick={handleKeyPress}
                    width="8%"
                  />

                  <KeyboardKey
                    char="SPACE"
                    onClick={handleKeyPress}
                    width="28%"
                    bgColor="bg-white"
                    fontSize="text-sm"
                  />

                  <KeyboardKey
                    char="."
                    onClick={handleKeyPress}
                    width="8%"
                  />

                  <button
                    onClick={toggleLanguage}
                    className={`rounded-xl shadow-md flex items-center justify-center
                      active:scale-95 transition-all duration-300 ${
                        isLanguageChanging 
                          ? 'bg-orange-600 scale-110' 
                          : 'bg-orange-500 hover:bg-orange-600'
                      }`}
                    style={{ width: '9%' }}
                  >
                    <Globe className={`w-5 h-5 text-white transition-transform duration-300 ${
                      isLanguageChanging ? 'rotate-180' : ''
                    }`} />
                  </button>

                  <button
                    onClick={() => handleKeyPress('ENTER')}
                    className="bg-blue-500 rounded-xl shadow-md flex items-center justify-center
                      hover:bg-blue-600 active:scale-95 transition-all duration-150"
                    style={{ width: '9%' }}
                  >
                    <CornerDownLeft className="w-5 h-5 text-white" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
